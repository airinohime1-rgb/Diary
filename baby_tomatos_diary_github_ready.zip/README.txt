BABY TOMATO'S DIARY
A cosy, installable writing space for projects and chapters.

WHAT'S INCLUDED
- Project library with search, favourites, sorting and custom cover colours
- Chapters inside each project
- Handlee-style writing editor, with live word count and autosave
- Local storage: writing is saved in this browser on this device
- JSON backup export and import
- Installable PWA shell with offline app loading after the first successful online visit

IMPORTANT ABOUT YOUR DIARY DATA
Your writing is stored locally in the browser on the device where you use the diary. It is not automatically synced to Google Drive or another device. Use the Export button regularly to download a backup JSON file. Keep that backup somewhere safe.

HANDLEE FONT
The app requests Handlee from Google Fonts. An internet connection is needed the first time the font is loaded. The browser may cache the font for later use, but offline font availability depends on the browser's cache. A rounded system-font fallback is included.

HOW TO GET YOUR OWN GOOGLE CHROME LINK
This folder is a ready-to-host website. It does not yet have a public internet address. To create one:
1. Open https://app.netlify.com/drop in Chrome.
2. Sign in or create a Netlify account.
3. Upload the unzipped baby_tomatos_diary folder (the folder containing index.html).
4. Netlify will publish it and give you a website link.
5. Open that link in Chrome on your phone. Use Chrome's menu (⋮) > Add to Home screen or Install app.

For offline support, open the published link once while online, then install it. The app shell is cached for offline reopening. Your saved writing remains in that browser's local storage.

PRIVACY
This starter app has no account system and sends no diary entries to a server. The only external request is for the Handlee/Nunito fonts from Google Fonts. Your entries stay in this browser unless you export and share a backup yourself.

For best results, do not clear Chrome's site data unless you have exported a backup first.
